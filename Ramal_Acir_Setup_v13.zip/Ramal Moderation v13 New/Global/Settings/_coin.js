module.exports = {
    sistem: true,
    kacmilisaniyesonra: "600000",
    kacmesajdabir: "10",
    BioCoin: "5000",
    
    Ödül: {
        Taglı: "5",
        Yetkili: "5",
        Kayıt: "1",
        Invite: "1",
        Mesaj: "1",
        Ses: "10",
    },

    Ürünler: [
        { Id: "1", UrunEmoji: "942426344317411388", UrunIsmi: "Kahramanlık", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "5000", Rol: true, RolID: "942431624509927424", Extra: false, Sat: true },
        { Id: "2", UrunEmoji: "936180548353806346", UrunIsmi: "Star", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "15000", Rol: true, RolID: "942431627697586187",  Extra: false, Sat: true },
        { Id: "3", UrunEmoji: "942428143522836480", UrunIsmi: "Legendary", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "100000", Rol: true, RolID: "942431631107584020", Extra: false, Sat: true },
        { Id: "4", UrunEmoji: "934877069811273770", UrunIsmi: "Sehira", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "2500", Rol: true, RolID: "942431634077126726", Extra: false, Sat: true },
        { Id: "5", UrunEmoji: "942428423786225754", UrunIsmi: "Genesis", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "50000", Rol: true, RolID: "942431636790861834", Extra: false, Sat: true },
        { Id: "6", UrunEmoji: "942428917535481886", UrunIsmi: "Kingdom", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "48000", Rol: true, RolID: "942431639521341510", Extra: false, Sat: true },
	    { Id: "7", UrunEmoji: "942429416020115496", UrunIsmi: "Diamond", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "250000", Rol: true, RolID: "942431642394427392", Extra: false, Sat: false },
	    { Id: "8", UrunEmoji: "942429831151357992", UrunIsmi: "Brave", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "100000", Rol: true, RolID: "942431645095559249", Extra: false, Sat: false },
	    { Id: "9", UrunEmoji: "942430006137729116", UrunIsmi: "Richer", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "35000", Rol: true, RolID: "942431648304214057", Extra: false, Sat: false },

	
        { Id: "10", UrunEmoji: "942430220202434650", UrunIsmi: "Heart Cape", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "15000", Rol: true, RolID: "942431651852607508", Extra: false, Sat: false },
        { Id: "11", UrunEmoji: "942430418291019796", UrunIsmi: "Devil", UrunTuru: "Rozet", UrunDetay: "Profilinizde çok hoş durabilcek bir rozet", UrunFiyat: "350000", Rol: true, RolID: "942431655195459584", Extra: false, Sat: false },
    
    ],
}