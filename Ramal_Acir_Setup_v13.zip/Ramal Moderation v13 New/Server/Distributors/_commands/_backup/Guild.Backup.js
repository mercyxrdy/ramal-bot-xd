const { Client, Message, MessageEmbed } = require("discord.js");
const { genEmbed } = require("../../../../Global/Init/Embed");
const { guildBackup } = require('../../../../Global/Init/Guild.Backup');
module.exports = {
    Isim: "backup",
    Komut: ["yedekal"],
    Kullanim: "yedek @sehira/ID",
    Aciklama: "Sunucudaki üyeler içerisinde tagı olmayanları kayıtsıza at.",
    Kategori: "-",
    Extend: false,
    
   /**
   * @param {Client} client 
   */
  onLoad: function (client) {

  },

   /**
   * @param {Client} client 
   * @param {Message} message 
   * @param {Array<String>} args 
   */

  onRequest: async function (client, message, args) {
    const embed = new genEmbed() 
    await guildBackup.guildChannels()
    await guildBackup.guildRoles()
    message.channel.send({embeds: [embed.setFooter("dilediğiniz zaman istediğiniz tarihin yedeğini tekrardan kurabilirsiniz.").setDescription(`${message.guild.emojiGöster(emojiler.Onay)} Başarıyla \`${message.guild.name}\` sunucusunun son bir saat olan yedeklemesi **${tarihsel(Date.now())}** tarihinde alındı ve kayıtlara işlendi.`)]})
    .then(x => {
        setTimeout(() => {
            x.delete().catch(err => {})
        }, 8500);
    })
    message.react(message.guild.emojiGöster(emojiler.Onay))
    client.logger.log(`ROL => Manuel olarak backup işlemi gerçekleştirildi. (${message.author.tag})`, "backup") 
 }
};